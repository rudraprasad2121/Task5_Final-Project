<?php include 'db.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Posts</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>;p
<body class="bg-light">

<div class="container mt-4">
    <h2 class="mb-4"> All Posts</h2>
    <a href="add_post.php" class="btn btn-primary mb-3">➕ Add New Post</a>

    <!-- Search Form -->
    <form method="GET" action="view_posts.php" class="mb-4 d-flex">
        <input type="text" name="q" class="form-control me-2" placeholder="🔍 Search posts..." 
               value="<?php echo isset($_GET['q']) ? htmlspecialchars($_GET['q']) : ''; ?>">
        <button type="submit" class="btn btn-outline-secondary">Search</button>
    </form>

<?php
// Pagination settings
$postsPerPage = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $postsPerPage;

// Handle search
$search = "";
if (isset($_GET['q']) && !empty(trim($_GET['q']))) {
    $search = $conn->real_escape_string($_GET['q']);
    $sql = "SELECT * FROM posts 
            WHERE title LIKE '%$search%' 
               OR content LIKE '%$search%' 
            ORDER BY created_at DESC 
            LIMIT $postsPerPage OFFSET $offset";

    $countSql = "SELECT COUNT(*) as total FROM posts 
                 WHERE title LIKE '%$search%' 
                    OR content LIKE '%$search%'";
} else {
    $sql = "SELECT * FROM posts 
            ORDER BY created_at DESC 
            LIMIT $postsPerPage OFFSET $offset";

    $countSql = "SELECT COUNT(*) as total FROM posts";
}

$result = $conn->query($sql);
$countResult = $conn->query($countSql);
$totalPosts = $countResult->fetch_assoc()['total'];
$totalPages = ceil($totalPosts / $postsPerPage);

// Display posts
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<div class="card mb-3 shadow-sm">';
        echo '  <div class="card-body">';
        echo '      <h5 class="card-title">' . htmlspecialchars($row['title']) . '</h5>';
        echo '      <h6 class="card-subtitle mb-2 text-muted">Posted on: ' . $row['created_at'] . '</h6>';
        echo '      <p class="card-text">' . nl2br(htmlspecialchars($row['content'])) . '</p>';
        echo '      <a href="edit_post.php?id=' . $row['id'] . '" class="btn btn-sm btn-warning">Edit</a> ';
        echo '      <a href="delete_post.php?id=' . $row['id'] . '" onclick="return confirm(\'Are you sure you want to delete this post?\');" class="btn btn-sm btn-danger">Delete</a>';
        echo '  </div>';
        echo '</div>';
    }
} else {
    echo '<p class="alert alert-info">No posts found.</p>';
}

// Pagination links
if ($totalPages > 1) {
    echo '<nav><ul class="pagination">';
    for ($i = 1; $i <= $totalPages; $i++) {
        $active = ($i == $page) ? 'active' : '';
        $qParam = $search ? "&q=" . urlencode($search) : "";
        echo '<li class="page-item ' . $active . '"><a class="page-link" href="view_posts.php?page=' . $i . $qParam . '">' . $i . '</a></li>';
    }
    echo '</ul></nav>';
}

$conn->close();
?>

</div>
</body>
</html>
