<?php
include 'config.php';
echo "✅ Database connected successfully!";
?>