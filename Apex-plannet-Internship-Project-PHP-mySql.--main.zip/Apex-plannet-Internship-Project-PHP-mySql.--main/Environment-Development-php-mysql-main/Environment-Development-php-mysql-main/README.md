# Environment-Development-php-mysql.
setup environment development
# My PHP Project

A simple PHP project to demonstrate local server setup and version control using Git and GitHub.

---

## 🛠️ Project Setup

### 1. Install Local Server Environment

- Download and install [XAMPP](https://www.apachefriends.org/index.html) (or WAMP/MAMP).
- Start **Apache** and **MySQL** from the XAMPP control panel.
- Place your project folder (`Mysql-php-main`) inside the `htdocs` directory:
