<?php
include 'config.php';
echo "✅ Database connected successfully!";

?>

// Developed by @Ritesh Kumar Jena 
