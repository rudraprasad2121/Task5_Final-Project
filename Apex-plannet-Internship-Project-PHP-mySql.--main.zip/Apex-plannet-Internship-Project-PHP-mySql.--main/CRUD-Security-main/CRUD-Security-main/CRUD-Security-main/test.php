//Ritesh Kumar Jena
<?php
include 'config.php';
echo "✅ Database connected successfully!";

?>
